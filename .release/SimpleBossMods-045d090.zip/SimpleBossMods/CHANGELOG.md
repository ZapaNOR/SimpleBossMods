# Simple BossMods

## [045d090](https://github.com/ZapaNOR/SimpleBossMods/tree/045d090508159146dc6ff5001fc5ca7020313169) (2026-01-18)
[Full Changelog](https://github.com/ZapaNOR/SimpleBossMods/commits/045d090508159146dc6ff5001fc5ca7020313169) 

- Another test release  
- release test  
- initial commit  
