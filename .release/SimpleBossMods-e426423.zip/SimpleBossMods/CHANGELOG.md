# Simple Boss Mods (SBM)

## [e426423](https://github.com/ZapaNOR/SimpleBossMods/tree/e426423aaffe7d6cc8193b0ddbd027a4f906c2fb) (2026-01-19)
[Full Changelog](https://github.com/ZapaNOR/SimpleBossMods/commits/e426423aaffe7d6cc8193b0ddbd027a4f906c2fb) 

- Bar color setting, cleanup, use timeline API for testing bars  
- Merge branch 'main' of https://github.com/ZapaNOR/SimpleBossMods  
- Note, testing timeline  
- Merge pull request #1 from DaleHuntGB/shadow-removal  
    Shadow removal, respect gap setting  
- bar growth should respect gap  
- remove shadows from font  
- Now release works!  
- Another test release  
- release test  
- initial commit  
